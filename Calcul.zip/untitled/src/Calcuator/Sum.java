package Calcuator;

import java.util.Arrays;

public class Sum {
    public static void main(String[] args) {
        int n = 10;
        while (n != 0) {
            if (n == 6) {
                n--;
                continue;
            }

            System.out.println(n);
            n--;

        }
    }
}
